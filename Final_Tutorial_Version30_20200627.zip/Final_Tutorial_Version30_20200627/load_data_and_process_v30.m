
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% v05: including eccentricity and aspect ratio statistics
% v10: remove the lorentdistribution curve fitting from plot. If necessary, 
% go back to v05 to obtain the code for curve fitting. Fitting algorithms 
% are still here. But without plot out the results. 

% v20:(11/13/2009) use only one .MAT file to process all the data necesary
% v20:remove lorentzian fitting of the data, and curvefitted record to
% written to excel
% v20: if need to retrieve the lorentzian fitting, go back to v10 
%
% v30: remove the part to re-distribution the fringe_separation_group_X
%      directly use the separation_group and fringe_separation_group to
%      plot the fringe separation histogram
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%load FT_SingleC33_500kE6_local.MAT
%load BioD47_SingleC_500kE7_local.MAT 
%load BP15_SingleC_13_D10_500k_local.MAT 

%load VWModel_Fullerenic.MAT 
fringe_and_space_analysis_data='VWModel_Fullerenic_demo.MAT';

load(fringe_and_space_analysis_data)


excel_file_name='DemoFullerenic.xls';
excel_datasheet_name='DemoFullerenic';


Write_Excel_Flag=input('Do you want to write results into excel? Y: yes, N: No\n','s');

if ((Write_Excel_Flag=='Y')|(Write_Excel_Flag=='y')) 
        DATA_sample_record=[{'Raw_image:'},{file_name},{'Run_date'}, {datestr(now)} ; ...
                            {'Fringe_Analysis'},{fringe_and_space_analysis_data},{'Fringe_Space_Analysis'},{fringe_and_space_analysis_data}; ...
                            {'image_row_num'}, {' image_column_num'}, {' pixel_to_nm'}, {'total_valid_fringe'};...
                            num2cell([size(broken_image_updated) pixel_to_nm ]), num2cell(number_of_fringes);...
                            {'average_fringe_length'}, {'fringe_length_deviation'}, ...
                            {'average_tortuosity'}, {'tortuosity_deviation'}; ...
                            num2cell([mean(fringe_length) std(fringe_length) mean(tortuosity) std(tortuosity)])];
 
        DATA_sample_record_mean=[{'average_fringe_length'}, {'fringe_length_deviation'}, ...
                            {'average_tortuosity'}, {'tortuosity_deviation'}, ...
                            {'average_spacing'},{'spacing_deviation'}; ...
                            num2cell([mean(fringe_length) std(fringe_length) mean(tortuosity) std(tortuosity) mean(fringe_space_nm) std(fringe_space_nm)])];
        DATA_sample_record_median=[{'median_fringe_length'},{'median_tortuosity'},{'median_spacing'};...
                                      num2cell([median(fringe_length) median(tortuosity) median(fringe_space_nm)])];
        Image_process_parameter=[{'contrast enhance'},{'filter size'},{'filter sigma'},{'disk size background'},{'square size close'},{'square size open'},{'BW threshold'}; ...
                               {Flag_contrast_option},num2cell([filter_size filter_sigma disk_size_background square_size_close square_size_open BW_threshold])];

        DATA_length_STATS=[ {'length', 'percentage'};num2cell([length_group ;fringe_length_group]')];
        DATA_tortuosity_STATS=[{'tortuosity', 'percentage'};num2cell([tortuosity_group ;fringe_tortuosity_group]')];
        DATA_separation_STATS=[{'separation', 'percentage'};num2cell([separation_group ;fringe_separation_group]')];
        xlswrite(excel_file_name, DATA_sample_record, excel_datasheet_name, 'A1')
        xlswrite(excel_file_name, DATA_sample_record_mean, excel_datasheet_name, 'G1')
        xlswrite(excel_file_name, DATA_sample_record_median, excel_datasheet_name, 'G3')
        xlswrite(excel_file_name, Image_process_parameter, excel_datasheet_name, 'A8')
        xlswrite(excel_file_name, DATA_length_STATS, excel_datasheet_name, 'A11')
        xlswrite(excel_file_name, DATA_tortuosity_STATS, excel_datasheet_name, 'D11')
        xlswrite(excel_file_name, DATA_separation_STATS, excel_datasheet_name, 'G11')
end 


figure(1);
imagesc(m_user_selected_ROI);
title('Original Image with selected ROI');
colormap(gray);
axis image;
[Hscale,Htext]=plot_scale([200 950],pixel_to_nm,5,'r','nm','h');

figure(2);
imagesc(m);
title('Scale Invert Image');
colormap(gray);
axis image;

figure(3);
imagesc(m_equalized);
title('Image of Contrast Enhancement');
colormap(gray);
axis image;

figure(4);
imagesc(abs(GaussianLowpassFilteredmInverseTransform));
title('Inverse Gaussuab Lowpass Filtered Image Spatial Image');
colormap(gray);
axis image;

figure(5)
imagesc(Image_removingBakcground);
title('Removing Background Image');
colormap(gray);
axis image;

figure(6)
imagesc(BW_image);
title('Binarized Image');
colormap(gray);
axis image;

figure(7)
imagesc(or(BW_refined,ROI_edge));
title('Binarized Image');
colormap(gray);
axis image;

figure(8)
imagesc(or(BW_noborder,ROI_edge));
title('No-border Refined Binarized Image');
colormap(gray);
axis image;

figure(9)
imagesc(BW_sk);
title('Skeletonized No-border Refined Binarized Image');
colormap(gray);
axis image;

figure(10)
imagesc(RGB_image_with_nodes);
title('Image with marked nodes');
axis image;

figure(11)
imagesc(broken_image);
title('Breaking Triple and Quadruple cross point Image');
colormap(gray);
axis image;

figure (12)
imagesc(broken_image_updated);
title('Updated point Image after removing short length');
colormap(gray);
axis image;


figure(13)
bar(fringe_length)
title('fringe length statistics');

figure(14)
bar(length_group, fringe_length_group)
title('fringe length distribution');
axis([0 6 0 30])
xlabel('fringe length (nm)')
ylabel('percentage')

figure(15)
bar(tortuosity)
title('tortuosity statistics');

figure(16)
bar(tortuosity_group, fringe_tortuosity_group)
title('tortuosity distribution');
axis([1 3.0 0 30])
xlabel('fringe tortuosity')
ylabel('percentage')

%dilated_broken_image_updated=broken_image_updated;

figure(17)
bar(fringe_orientation)
title('orientation statistics');

figure(18)
bar(orientation_group, fringe_orientation_group)
%title('tortuosity distribution');
axis([-180 180 0 20])

figure(19)
bar(fringe_space_nm)
title('fringe spacing statistics (nm)');

figure(20)
bar(separation_group, fringe_separation_group)
title('separation distribution');
axis([0.3 0.7 0 30])


figure(21)
bar(fringe_eccentricity)
title('fringe eccentricity statistics');

figure(22)
bar(eccentricity_group, fringe_eccentricity_group)
title('eccentricity distribution');


figure(23)
bar(fringe_aspect_ratio)
title('fringe aspect ratio statistics');

figure(24)
bar(aspect_ratio_group, fringe_aspect_ratio_group)
title('aspect ratio distribution');

figure(25)
imagesc(ROI_image);
title('SOI Image');
colormap(gray);
axis image;
[Hscale,Htext]=plot_scale([800 150],pixel_to_nm,5,'r','nm','h');

figure(26)
imagesc(RGB_image);
title('RGB Image');
axis image;
[Hscale,Htext]=plot_scale([150 950],pixel_to_nm,5,'r','nm','h');

figure(27)
imagesc(RGB_broken_image_updated);
title('Selected Fringes Yellow:1time,Magenta:2times, Cyan:3times, Red:4times, Green:5time, Blue:more times');
axis image;

figure(28);
bar(ROI_hist);

figure(29)
[ROI_hist_equalized,x]=imhist(m_equalized,256);
ROI_hist_equalized(1)=ROI_hist_equalized(1)-zero_outside_ROI;
ROI_hist_equalized=ROI_hist_equalized/length(find(ROI_window));
bar(ROI_hist_equalized)




figure(30)
bar(separation_group, fringe_separation_group)
title('separation distribution');
axis([0.3 0.7 0 30])
xlabel('fringe separation(nm)')
ylabel('percentage')

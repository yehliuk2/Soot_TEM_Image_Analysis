function analysis_fringe_v30()

clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code is based on the code "Analysis_Test2.m"
% v05: include option for using low pass filter or not
% v06: include the calculation of aspect ratio and eccentricity. 
% v10: 10/09/2009. Clear up image processing part. Only fringe analysis
%      algorithm remains. 
% v11: 11/6/2009 if a fringe is a circular (circle-like) 
%        size(i,1)~=2
%         i=[1;1]
%        j=[1;2]
%        end     which makes the tortuosity very large, but not infinitely 
%                large
% v30: 04/20/2010 change the bar space (bins) of fringe length from 
%      0.1nm => 0.1nm, change the number of group tortuosity from 50 to 
%      60, therefore that range is 0-6 nm (we chose to use a smaller bins 
%      than Dr. VW to discriminate smaller difference, in one paper he 
%      used 0.12nm, in another he used 0.3nm)
%      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load image
file_image_processed_name = 'VWModel_Fullerenic_demo.MAT';
save_fringe_analysis_name = 'VWModel_Fullerenic_demo.MAT';



% excel_file_name='VWTEM_ModelImage.xls';
% excel_datasheet_name='VWModel_Fullerenic';

load(file_image_processed_name);

BW_Analysis_updated=bwlabel(broken_image_updated);
STATS_updated=regionprops(BW_Analysis_updated, 'all');
number_of_stats_updated=size(STATS_updated,1)

% find end points pair %
end_point_pair=zeros(2,2,number_of_stats_updated);
end_point_distance=zeros(1,number_of_stats_updated);
for indx=1:number_of_stats_updated
    image_fringe_temp=(BW_Analysis_updated==indx);
    image_fringe_of_interest=FindEndand34druple(image_fringe_temp,'end');
    find_end_indx=indx
    [i,j]=find(image_fringe_of_interest==1);
    if size(i,1)~=2
        i=[1;1]
        j=[1;2]
    end
    end_point_pair(:,:,indx)=[i j]; 
    end_point_pixels(1,indx)=sqrt(diff(i)^2+diff(j)^2);
end
end_point_distance=end_point_pixels*pixel_to_nm;

number_of_fringes=size(STATS_updated,1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Redefine fringe_length
fringe_length_pixels=[];
for indx=1:number_of_fringes
    fringe_length_pixels=[fringe_length_pixels STATS_updated(indx).Perimeter];
end
% Note: The division by 2 in the equation below is not an error. It is
% because we take advantage of the built-in function (regionprops) to
% obtain the Perimeter of an isolated object. When the object is a 1 pixel
% thin skeleton, the lenght of the object = the perimeter/2
fringe_length=fringe_length_pixels/2*pixel_to_nm;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tortuosity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fringe_length_pixels/2
%end_point_pixels
%fringe_length
%end_point_distance
tortuosity=fringe_length./end_point_distance;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Orientation 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
fringe_orientation=[];
for indx=1:number_of_fringes
    fringe_orientation=[fringe_orientation STATS_updated(indx).Orientation];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eccentricity 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
fringe_eccentricity=[];
for indx=1:number_of_fringes
    fringe_eccentricity=[fringe_eccentricity STATS_updated(indx).Eccentricity];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aspect Ratio = MajorAxisLength/MinorAxisLength
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
fringe_aspect_ratio=[];
for indx=1:number_of_fringes
    fringe_aspect_ratio=[fringe_aspect_ratio STATS_updated(indx).MajorAxisLength/STATS_updated(indx).MinorAxisLength];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% grouping fringe length
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
number_group_length=60; % Conform to Dr. Vander Wal's paper 0nm - 17.7nm, bins 0.3nm
length_group_space=0.1 %nm
length_group=0:length_group_space:number_group_length*length_group_space;
fringe_length_group=zeros(1,number_group_length+1);
for indx=1:number_group_length
      fringe_length_group(indx)=sum(fringe_length>=(indx-1)*length_group_space & fringe_length<(indx)*length_group_space);
end
fringe_length_group(number_group_length+1)=number_of_fringes-sum(fringe_length_group);
fringe_length_group=fringe_length_group/number_of_fringes*100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% grouping fringe tortuosity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
number_group_tortuosity=50; % Conform to Dr. Vander Wal's paper 1.0 - 2.0, nins 0.02
tortuosity_group_space=0.02;
% The smallest value of tortuosity is 1.0 (straight)
tortuosity_group=1.0:tortuosity_group_space:1.0+number_group_tortuosity*tortuosity_group_space;
fringe_tortuosity_group=zeros(1,number_group_tortuosity+1);
for indx=1:number_group_tortuosity
      fringe_tortuosity_group(indx)=sum(tortuosity>=(1.0+(indx-1)*tortuosity_group_space) & tortuosity<(1.0+(indx)*tortuosity_group_space));
end
fringe_tortuosity_group(number_group_tortuosity+1)=number_of_fringes-sum(fringe_tortuosity_group);
fringe_tortuosity_group=fringe_tortuosity_group/number_of_fringes*100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% grouping orientation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
number_group_orientation=18;
orientation_group_space=10;
orientation_group=-orientation_group_space*(number_group_orientation/2-1):orientation_group_space:orientation_group_space*number_group_orientation/2;
fringe_orientation_group=zeros(1,number_group_orientation);
for indx=1:number_group_orientation-1
        fringe_orientation_group(indx)=sum(fringe_orientation>=((indx-number_group_orientation/2-1)*orientation_group_space) & fringe_orientation<((indx-number_group_orientation/2)*orientation_group_space));
end
fringe_orientation_group(number_group_orientation)=number_of_fringes-sum(fringe_orientation_group);
fringe_orientation_group=fringe_orientation_group/number_of_fringes*100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% grouping eccentricity 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
number_group_eccentricity=100;
eccentricity_group_space=0.001;
eccentricity_group=0.9+eccentricity_group_space:eccentricity_group_space:0.9+number_group_eccentricity*eccentricity_group_space;
fringe_eccentricity_group=zeros(1,number_group_eccentricity);
fringe_eccentricity_group(1)=sum(fringe_eccentricity<(0.9+(1)*eccentricity_group_space));
for indx=2:number_group_eccentricity-1
        fringe_eccentricity_group(indx)=sum(fringe_eccentricity>=(0.9+(indx-1)*eccentricity_group_space) & fringe_eccentricity<(0.9+(indx)*eccentricity_group_space));
end
fringe_eccentricity_group(number_group_eccentricity)=number_of_fringes-sum(fringe_eccentricity_group);
fringe_eccentricity_group=fringe_eccentricity_group/number_of_fringes*100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% grouping Aspect ratio - MajorAxisLength/MinorAxisLength
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
number_group_aspect_ratio=25;
aspect_ratio_group_space=1;
aspect_ratio_group=1.0+aspect_ratio_group_space:aspect_ratio_group_space:1.0+number_group_aspect_ratio*aspect_ratio_group_space;
fringe_aspect_ratio_group=zeros(1,number_group_aspect_ratio);
for indx=1:number_group_aspect_ratio-1
      fringe_aspect_ratio_group(indx)=sum(fringe_aspect_ratio>=(1.0+(indx-1)*aspect_ratio_group_space) & fringe_aspect_ratio<(1.0+(indx)*aspect_ratio_group_space));
end
fringe_aspect_ratio_group(number_group_aspect_ratio)=number_of_fringes-sum(fringe_aspect_ratio_group);
fringe_aspect_ratio_group=fringe_aspect_ratio_group/number_of_fringes*100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Record analysis result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Below is for writing to the TXT file
% fid=fopen('TEM_analysis_record.txt','a');
% fprintf(fid, ['file_name' ' date_time' '\n'] );
% fprintf(fid, [file_name ' ' datestr(now) '\n'] );
% fprintf(fid, ['image_row_num' ' image_column_num' ' pixel_to_nm' '\n']);
% fprintf(fid, '%3d %3d %6.5f \n',[size(broken_image_updated) pixel_to_nm ]); 
% fprintf(fid, 'Valid fringe number: %d \n', number_of_fringes);
% fprintf(fid, [' average_fringe_length' ' fringe_length_deviation' ' average_tortuosity' ' tortuosity_deviation' '\n']);
% fprintf(fid, '%6.5f %6.5f %6.4f %6.4f\n',[mean(fringe_length) std(fringe_length) mean(tortuosity) std(tortuosity)]); 
% fprintf(fid, '\n');
% fclose(fid);


% DATA_sample_record=[{'Raw_image:'},{file_name},{'Run_date'}, {datestr(now)} ; ...
%                     {'image_row_num'}, {' image_column_num'}, {' pixel_to_nm'}, {'total_valid_fringe'};...
%                     num2cell([size(broken_image_updated) pixel_to_nm ]), num2cell(number_of_fringes);
%                     {'average_fringe_length'}, {'fringe_length_deviation'}, ...
%                     {'average_tortuosity'}, {'tortuosity_deviation'}; ...
%                     num2cell([mean(fringe_length) std(fringe_length) mean(tortuosity) std(tortuosity)])];
% 
% DATA_length_STATS=[ {'length', 'percentage'};num2cell([length_group ;fringe_length_group*100]')];
% DATA_tortuosity_STATS=[{'tortuosity', 'percentage'};num2cell([tortuosity_group ;fringe_tortuosity_group*100]')];
% DATA_orientation_STATS=[{'orientation', 'percentage'};num2cell([orientation_group ;fringe_orientation_group*100]')];
% xlswrite(excel_file_name, DATA_sample_record, excel_datasheet_name, 'A1')
% xlswrite(excel_file_name, DATA_length_STATS, excel_datasheet_name, 'A11')
% xlswrite(excel_file_name, DATA_tortuosity_STATS, excel_datasheet_name, 'E11')
% xlswrite(excel_file_name, DATA_orientation_STATS, excel_datasheet_name, 'E11')

save(save_fringe_analysis_name);


figure(1);
imagesc(image_gray);
title('Original Image');
colormap(gray);
axis image;


figure(2);
imagesc(m);
title('Scale Invert Image');
colormap(gray);
axis image;


figure(3)
imagesc(m_equalized);
title('Image of Contrast Enhancement');
colormap(gray);
axis image;

% figure(4);
% colormap(gray);
% subplot(221)
% imagesc(GaussianLowpassFilterSpectrum_Logmagnitude);
% title('Log Magnitude of Gaussian Lowpass Filter Spectrum');
% axis image;
% 
% subplot(222);
% imagesc(GaussianLowpassFilterSpectrum_Phase);
% title('Phase of Gaussian Lowpass Filter Spectrum');
% axis image;
% 
% subplot(223);
% imagesc(GaussianLowpassFilteredSpectrum_Logmagnitude);
% title('Log Magnitude of Gaussian Lowpass Filtered Image 2D FFT Spectrum');
% axis image;
% 
% subplot(224);
% imagesc(GaussianLowpassFilteredSpectrum_Phase);
% title('Phase of Gaussian Lowpass Filtered Image 2D FFT Spectrum');
% axis image;

figure(4);
imagesc(abs(GaussianLowpassFilteredmInverseTransform));
title('Inverse Gaussuab Lowpass Filtered Image Spatial Image');
colormap(gray);
axis image;

figure(5)
imagesc(Image_removingBakcground);
title('Removing Background Image');
colormap(gray);
axis image;

figure(6)
imagesc(BW_image);
title('Binarized Image');
colormap(gray);
axis image;

figure(7)
imagesc(BW_refined);
title('Binarized Image');
colormap(gray);
axis image;

figure(8)
imagesc(BW_noborder);
title('No-border Refined Binarized Image');
colormap(gray);
axis image;

figure(9)
imagesc(BW_sk);
title('Skeletonized No-border Refined Binarized Image');
colormap(gray);
axis image;

figure(10)
imagesc(RGB_image_with_nodes);
title('Image with marked nodes');
axis image;

figure(11)
imagesc(broken_image);
title('Breaking Triple and Quadruple cross point Image');
colormap(gray);
axis image;

figure (12)
imagesc(broken_image_updated);
title('Updated point Image after removing short length');
colormap(gray);
axis image;


figure(13)
bar(fringe_length)
title('fringe length statistics');

figure(14)
bar(length_group, fringe_length_group)
title('fringe length distribution');

figure(15)
bar(tortuosity)
title('tortuosity statistics');

figure(16)
bar(tortuosity_group, fringe_tortuosity_group)
title('tortuosity distribution');

figure(17)
bar(fringe_orientation)
title('fringe orientation statistics');

figure(18)
bar(orientation_group, fringe_orientation_group)
title('orientation distribution');

figure(19)
bar(fringe_eccentricity)
title('fringe eccentricity statistics');

figure(20)
bar(eccentricity_group, fringe_eccentricity_group)
title('eccentricity distribution');

figure(21)
bar(fringe_aspect_ratio)
title('fringe aspect ratio statistics');

figure(22)
bar(aspect_ratio_group, fringe_aspect_ratio_group)
title('aspect ratio distribution');


figure(23)
subplot(211)
imagesc(ROI_image);
title('SOI Image');
colormap(gray);
axis image;
[Hscale,Htext]=plot_scale([800 150],pixel_to_nm,6,'r','nm','h');

subplot(212)
imagesc(RGB_image);
title('RGB Image');
axis image;
[Hscale,Htext]=plot_scale([800 150],pixel_to_nm,6,'r','nm','h');

end
clear all;
close all;

fringe_and_space_analysis_data='VWModel_Fullerenic_demo.MAT';

load(fringe_and_space_analysis_data)


txt_file_name='test.txt';

%use '\t' to separate items
fid=fopen(txt_file_name,'a');
fprintf(fid, ['file_name' ' date_time' '\n'] );
fprintf(fid, [file_name '\t' datestr(now) '\n'] );
fprintf(fid, ['image_row_num' ' image_column_num' ' pixel_to_nm' '\n']);
fprintf(fid, '%3d %3d %6.5f \n',[size(broken_image_updated) pixel_to_nm ]); 
fprintf(fid, 'Valid fringe number: %d \n', number_of_fringes);
fprintf(fid, ['average_fringe_length' ' fringe_length_deviation' ' average_tortuosity' ' tortuosity_deviation' '\n']);
fprintf(fid, '%6.5f %6.5f %6.4f %6.4f\n',[mean(fringe_length) std(fringe_length) mean(tortuosity) std(tortuosity)]); 
fprintf(fid, '\n');
fclose(fid);

dlmwrite(txt_file_name,[length_group' fringe_length_group'],'-append','roffset', 1, 'delimiter','\t')


clear all;
close all;
image_file_name='VWModel_Fullerenic.tif';

image_gray=imread(image_file_name);

m_inverse=255-image_gray;




nm_to_pixel=29.6
pixel_to_nm=1/nm_to_pixel;


figure(1);
imagesc(m_inverse);
title('Original Image');
colormap(gray);
axis image;
hold on;
[Hscale,Htext]=plot_scale([100 900],pixel_to_nm,5,'r','nm','h');

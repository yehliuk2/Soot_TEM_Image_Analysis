function fringe_space_analyze_v30()

% Kuen Yehliu
% v11: 10/11/2009. Magnified the selected fringe pair, 
%      modify the pair length, and shown on the ROI image
% v20: 11/26/2009. Fixed the bug of magnifying selected fringe pair. Before
%      modify, there is sometimes an error when selecting a pair near the
%      border of the image. It was caused by the auto-magnification 
%      code that specify a range outside the image. 
% v30: This version is based on fringe_space_analyze_DrVW. The big change
%      is in adding the restriction of the possible fringe space. 0.3nm -
%      0.5 nm. (Vander Wal, 0.32-0.5nm, and Palotas, 0.3nm -0.45nm)And, 
%      debug the part of adding color whenever a fringe is selected once. 
%      The bin of fringe separation distance is set to 0.00625nm,group 
%      number set to is 90. Therefore, the max shown is 
%      0.25+40*0.00625=0.5 nm. 
% v30(07/04/2020): The same software as v30. Kuen just added a displat 

clear all;
close all;

%file_name='VWModel_Fullerenic_test.MAT';
%save_fringe_analysis_name='BP15_SingleC_13_D10_500k_01_test.MAT';
save_fringe_analysis_name='VWModel_Fullerenic_demo.MAT';
save_mat_name_space='VWModel_Fullerenic_demo.MAT';


%load(file_name);
load(save_fringe_analysis_name);

raw_image_size=size(m, 2);


figure(1)
imagesc(RGB_image);
title('ROI images with marked fringes');
axis image;

figure(2)
imagesc(broken_image);
title('broken images');
colormap(gray);
axis image;

figure(3)
imagesc(broken_image_updated);
title('Updated point Image after removing short length');
colormap(gray);
axis image;

selected_record=zeros(number_of_fringes,1);
fringe_space_pixels=[];

fringe_pair_record=[];
Flag_repeated_selection=0;
Flag_multiple_selection=0;
Flag_fringe_select='Y';
RGB_broken_image_updated(:,:,1)= broken_image_updated;  %R
RGB_broken_image_updated(:,:,2)= broken_image_updated;  %G
RGB_broken_image_updated(:,:,3)= broken_image_updated;  %B

%% 
% Kuen added the following comment on 7/4/2020 in order to help to user to
% understand what to do for selecting parallel pairs of fringes
disp('(1) Crop a retangle area in Figure 3;')
disp('(2) Select two parallel fringes in Figure 4;')
disp('(3) Select the lengths to be caculate the separation distance in Figure 5;')  
disp('(4) Follow the prompt message to keep selecting another pair or finish selecting.')




%%


while (Flag_fringe_select == 'Y')||(Flag_fringe_select == 'y')
     
    figure(3);
    [Temp,rect]=imcrop(RGB_broken_image_updated);   
    
    ROI_preselct_x=ceil(rect(1));
    ROI_preselct_y=ceil(rect(2));
    ROI_preselct_width=ceil(rect(3));
    ROI_preselct_height=ceil(rect(4));
    
    ROI_preselect_region= ...
       RGB_broken_image_updated(ROI_preselct_y:ROI_preselct_y+ ...
       ROI_preselct_height, ROI_preselct_x:ROI_preselct_x+ ...
       ROI_preselct_width,1:3);
    
    figure(4)
    imagesc(ROI_preselect_region);
    title('locally magnified')
    axis image; 
   
    ROI_pair_preselected=roipoly(ROI_preselect_region);
    ROI_pair=zeros(size(BW_Analysis));
    ROI_pair(ROI_preselct_y:ROI_preselct_y+ ...
       ROI_preselct_height, ROI_preselct_x:ROI_preselct_x+ ...
       ROI_preselct_width)=ROI_pair_preselected;
      

       pair_selected=BW_Analysis_updated.*ROI_pair;
       fringe_pair=sort(unique(pair_selected(find(pair_selected>0))));
       
       
       if (size(fringe_pair,1)~=2)
              Flag_multiple_selection=1
       else 
           for indx=1:size(fringe_pair_record,2)
                if (sum(fringe_pair_record(:,indx)==fringe_pair)==2);
                  Flag_repeated_selection=1
                end
           end
       end
              
      if(Flag_multiple_selection==1)|(Flag_repeated_selection==1)
           disp('error, please select only two fringes, or do not repeat selection');
           clear m_fringe_pair  
%       elseif (Flag_repeated_selection==1)
%            disp('error, repeat selection')
%            clear m_fringe_pair
      else  

                 m_fringe_pair=(BW_Analysis_updated==fringe_pair(1))|(BW_Analysis_updated==fringe_pair(2));
                 [r_fringe_pair_temp,c_fringe_pair_temp]=find(m_fringe_pair==1);  
                 upper_left=[min(r_fringe_pair_temp) min(c_fringe_pair_temp)]
                 lower_right=[max(r_fringe_pair_temp) max(c_fringe_pair_temp)]
                 fringe_pair_height=lower_right(1)-upper_left(1)
                 fringe_pair_width=lower_right(2)-upper_left(2)                 
                 fringe_pair_image_size=2^ceil(log2(max(fringe_pair_height,fringe_pair_width)))
                 starting_coordinate=[upper_left(1)-ceil((fringe_pair_image_size-fringe_pair_height)/2), ...
                     upper_left(2)-ceil((fringe_pair_image_size-fringe_pair_width)/2)]
                 starting_coordinate(starting_coordinate<=0)=1
                 starting_coordinate((starting_coordinate+fringe_pair_image_size-1)>=raw_image_size)= ...
                     raw_image_size- fringe_pair_image_size+1
                 m_fringe_pair_to_be_modified=m_fringe_pair(starting_coordinate(1):starting_coordinate(1)+...
                     fringe_pair_image_size-1,starting_coordinate(2):starting_coordinate(2)+...
                     fringe_pair_image_size-1);
            %      imagesc(RGB_broken_image_updated);
            %      axis image;

                figure(5)
                  
                   ROI_pair_modified=roipoly(m_fringe_pair_to_be_modified);
                   m_fringe_pair_modified_local=m_fringe_pair_to_be_modified.*ROI_pair_modified;
 
                figure(6)
                  imagesc(m_fringe_pair_modified_local);
                  title('locally magnified')
                  colormap(gray);
                  axis image; 
                  
                   m_fringe_pair_modified=zeros(size(m_fringe_pair));
                   m_fringe_pair_modified(starting_coordinate(1):starting_coordinate(1)+...
                     fringe_pair_image_size-1,starting_coordinate(2):starting_coordinate(2)+...
                     fringe_pair_image_size-1)=m_fringe_pair_modified_local;
                   m_fringe_pair_analysis=bwlabel(m_fringe_pair_modified);
                   
                   Flag_fringe_pair_modified_error=(length(unique(m_fringe_pair_analysis(m_fringe_pair_analysis>0))) ~=2)
                   if (Flag_fringe_pair_modified_error)
                        disp('error, please select only two fringes, or do not repeat selection');
                        clear m_fringe_pair_modified;
                        fringe_space_pixels
                        fringe_pair_record
                   else
                       
                        STATS_pair_temp=regionprops(m_fringe_pair_analysis,'PixelList');
                        [pair_size,min_indx]=min([size(STATS_pair_temp(1).PixelList,1),size(STATS_pair_temp(2).PixelList,1)])
                        max_indx=mod(min_indx,2)+1;

                        min_dist=zeros(1,pair_size);
                        for indx=1:pair_size
                             min_dist(indx)=min(sqrt((STATS_pair_temp(max_indx).PixelList(:,1)-STATS_pair_temp(min_indx).PixelList(indx,1)).^2 ...
                             +(STATS_pair_temp(max_indx).PixelList(:,2)-STATS_pair_temp(min_indx).PixelList(indx,2)).^2));
                        end
                        min_dist
                        average_space_distance_pixels=mean(min_dist)
                        
                        

% Kuen added this if-else loop to screening the separation space shorter 
% than 0.32, or longer than 0.5 nm  02/11/2010
                        ave_space_lower_limit=0.3*nm_to_pixel;
                        ave_space_upper_limit=0.5*nm_to_pixel;
                        if (average_space_distance_pixels<ave_space_lower_limit | average_space_distance_pixels>ave_space_upper_limit)
                            disp('error, space distance outside the range 0.32nm - 0.5nm');
                            clear m_fringe_pair_modified;
                        else
                            fringe_space_pixels=[fringe_space_pixels average_space_distance_pixels]
                            fringe_pair_record=[fringe_pair_record fringe_pair]
  
                            figure(7)
                            imagesc(m_fringe_pair_modified);
                            title('Modified Selected Fringe Pairs');
                            colormap(gray);
                            axis image;

                            selected_record(fringe_pair)=selected_record(fringe_pair)+1;
                              for indx=1:2
                                if selected_record(fringe_pair(indx))==1 % First time selected: Yellow
                                    RGB_broken_image_updated(:,:,1)= RGB_broken_image_updated(:,:,1);  %R
                                    RGB_broken_image_updated(:,:,2)= RGB_broken_image_updated(:,:,2);  %G
                                    RGB_broken_image_updated(:,:,3)= RGB_broken_image_updated(:,:,3)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0)); %B
                                elseif selected_record(fringe_pair(indx))==2 % 2nd time selected: Magenta
                                    RGB_broken_image_updated(:,:,1)= RGB_broken_image_updated(:,:,1);  %R
                                    RGB_broken_image_updated(:,:,2)= RGB_broken_image_updated(:,:,2)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %G
                                    RGB_broken_image_updated(:,:,3)= RGB_broken_image_updated(:,:,3)+imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0)); %B
                                elseif selected_record(fringe_pair(indx))==3 % 3rd time selected: Cyan 
                                    RGB_broken_image_updated(:,:,1)= RGB_broken_image_updated(:,:,1)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %R
                                    RGB_broken_image_updated(:,:,2)= RGB_broken_image_updated(:,:,2)+imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %G
                                    RGB_broken_image_updated(:,:,3)= RGB_broken_image_updated(:,:,3); %B
                                elseif selected_record(fringe_pair(indx))==4 % 4th time selected: Red   
                                    RGB_broken_image_updated(:,:,1)= RGB_broken_image_updated(:,:,1)+imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %R
                                    RGB_broken_image_updated(:,:,2)= RGB_broken_image_updated(:,:,2)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %G
                                    RGB_broken_image_updated(:,:,3)= RGB_broken_image_updated(:,:,3)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0)); %B
                                elseif selected_record(fringe_pair(indx))==5 % 5th time selected: Green  
                                    RGB_broken_image_updated(:,:,1)= RGB_broken_image_updated(:,:,1)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %R
                                    RGB_broken_image_updated(:,:,2)= RGB_broken_image_updated(:,:,2)+imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %G
                                    RGB_broken_image_updated(:,:,3)= RGB_broken_image_updated(:,:,3); %B    
                                else     % More than 5th time selected: Blue  
                                    RGB_broken_image_updated(:,:,1)= RGB_broken_image_updated(:,:,1);  %R
                                    RGB_broken_image_updated(:,:,2)= RGB_broken_image_updated(:,:,2)-imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0));  %G
                                    RGB_broken_image_updated(:,:,3)= RGB_broken_image_updated(:,:,3)+imdilate((BW_Analysis_updated==fringe_pair(indx)),strel('diamond',0)); %B                  
                                end
                                RGB_broken_image_updated(RGB_broken_image_updated>=1)=1;
                                RGB_broken_image_updated(RGB_broken_image_updated<=0)=0;
                              end

                        end
% End of modification of if-else loop 2/11/2010
                        
                        
                        
                        
                        
                   end  
            

        % Below is the if end                 
      end
         workspace;
         Flag_fringe_select=input('Continue to select a fringe pair? Y or y: Yes, N or n: No\n','s');
         Flag_repeated_selection=0 
         Flag_multiple_selection=0
         Flag_fringe_pair_modified_error=0
% This is the while end
end

fringe_space_nm=fringe_space_pixels*pixel_to_nm

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% grouping fringe separation distance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
number_of_selected_separation_distance=size(fringe_space_nm,2);
number_group_separation=40;
separation_group_space=0.00625;
separation_group=0.25:separation_group_space:0.25+number_group_separation*separation_group_space;
fringe_separation_group=zeros(1,number_group_separation+1);
for indx=1:number_group_separation
      fringe_separation_group(indx)=sum(fringe_space_nm>=(0.25+(indx-1)*separation_group_space) & fringe_space_nm<(0.25+(indx)*separation_group_space));
end
fringe_separation_group(number_group_separation+1)=number_of_selected_separation_distance-sum(fringe_separation_group);
fringe_separation_group=fringe_separation_group/number_of_selected_separation_distance*100;

RGB_broken_image_updated(RGB_broken_image_updated>=1)=1;
RGB_broken_image_updated(RGB_broken_image_updated<=0)=0;


%save(save_mat_name_space, 'separation_group','fringe_separation_group','RGB_broken_image_updated','fringe_space_nm')
save(save_mat_name_space);

figure(7)
imagesc(RGB_broken_image_updated);
title('Selected Fringes Yellow:1time,Magenta:2times, Cyan:3times, Red:4times, Green:5time, Blue:more times');
axis image;

figure(8)
bar(separation_group, fringe_separation_group)
title('fringe separation distribution');


end
function load_image_and_process_v30()
 
% Developed by Kuen Yehliu (MATLAB 2009a Student Version)
% This code loads the image from the file_name
% Operates image processing technique, iterate until 
% User feel satisfied about the results. 

% This code is based on the code "Analysis_Test2.m"
% v05: include option for using low pass filter or not
% v06: include the calculation of aspect ratio and eccentricity. 
% v10: manually or automatically (equalizing) improve contrast
% v11: localized the computation of threshold by Otsu's method 
% v12 (10/07/2009): clear up bugs and unnecessary parts of the program. 
% v13 (10/08/2009): move unnecessary parts of the program 
% v20 (11/13/2009): remove the function of centering ROI. It is not 
% necessary because it cause difficult when comparing with original image
% v20 (11/23/2009): reverse the order of imclose and imopen. In this
% version, imclose was used before imopen.
% v20 (11/23/2009): imopen and imclose element shape was changed to square,
% instead of diamond. 
% V30 (04/19/2010): use 0.5nm as the threshold to remove the physically
% impossible fringe length. 
% V30 (07/04/2020): verify this software works for MATLAB R2020a in Windows
% 10. 


clear all;
close all;
%% Definition

%file_name: name of the image file (must be 8 bit, gray-scale image)
%save_mat_name: file name to be saved after processing


% load image
%file_name='VWModel_Fullerenic.tif';
file_name='VWModel_Fullerenic.tif';
save_mat_name='VWModel_Fullerenic_demo.MAT';

% excel_file_name='VWTEM_ModelImage.xls';
% excel_datasheet_name='VWModel_Fullerenic';

image_gray=imread(file_name);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% REMEMBER TO CHANGE WHEN OPEN FILE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% WITH DIFFERENCE MAGNIFICATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 1 nm = ? pixels
%nm_to_pixel=1
%nm_to_pixel=22.763 % 240k
%nm_to_pixel=28.994 %300k
nm_to_pixel=29.6 % Given by Dr. VW
%nm_to_pixel=38.045 %400k
%nm_to_pixel=47.849 % 500k
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pixel_to_nm=1/nm_to_pixel;  %nm/pixel

%% Reverse the image (while=fringe, black=background), and select ROI

m_inverse=255-image_gray;



%%%%%%%%%%%%%%%%%%%%%%%%
% Newly built in Analysis_fringe_v01
figure_handle=figure(1);
Flag_ROI='Y';
ROI_window=zeros(size(m_inverse));
ROI_x=[];
ROI_y=[];
m_temp=m_inverse;

% 7/4/2020 Kuen added this displayed message to help the user %
disp('Select the ROI by clicking on the image direcrly and forma a polygonal shapes.')
disp('Double click after you select all points of one ROI.');

while (Flag_ROI=='Y')||(Flag_ROI=='y')
[ROI_window_temp, ROI_x_temp, ROI_y_temp]=roipoly(m_temp);
ROI_window=or(ROI_window,ROI_window_temp);
ROI_x=[ROI_x;ROI_x_temp];
ROI_y=[ROI_y;ROI_y_temp];
m_temp=m_temp.*uint8(~ROI_window);
Flag_ROI=input('Continue to select ROI? Y or y: Yes; N or n:No \n','s');
end 
clear m_temp ROI_x_temp ROI_y_temp;
m=m_inverse.*uint8(ROI_window);

%% Crop image and pad with zero Analysis_fringe_v03
%ROI_width=ceil((max(ROI_x)-min(ROI_x))/2)*2-1;
%ROI_height=ceil((max(ROI_y)-min(ROI_y))/2)*2-1;
%ROI_coordinate=[floor(min(ROI_x)) floor(min(ROI_y)) ROI_width ROI_height];
%m=imcrop(m,ROI_coordinate);
%image_size=2^ceil(log2(max(ROI_width, ROI_height)));
%m=padarray(m,[(image_size-ROI_height-1)/2 (image_size-ROI_width-1)/2]);

ROI_edge=imdilate(edge(ROI_window),strel('diamond',1));
%m_user_selected_ROI=image_gray+256*uint8(ROI_user_selected_edge);


m_user_selected_ROI(:,:,3)=double(image_gray)/255-ROI_edge;
m_user_selected_ROI(:,:,2)=double(image_gray)/255-ROI_edge;
m_user_selected_ROI(:,:,1)=double(image_gray)/255+ROI_edge;
m_user_selected_ROI(m_user_selected_ROI>=1)=1;
m_user_selected_ROI(m_user_selected_ROI<=0)=0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close(figure_handle)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Equalizing to improve contrast
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

zero_outside_ROI=numel(m)-length(find(ROI_window));
[ROI_hist,x]=imhist(m,256);
ROI_hist(1)=ROI_hist(1)-zero_outside_ROI;
ROI_hist=ROI_hist/length(find(ROI_window));

%     figure(1);
%     imshow(m);
%     axis image;
% 
%     figure(2);
%     bar(ROI_hist);
% 
%     figure(3) 
%     imshow(m_equalized)
%     axis image;
% 
%     figure(4)
%     [ROI_hist_equalized,x]=imhist(m_equalized,256);
%     ROI_hist_equalized(1)=ROI_hist_equalized(1)-zero_outside_ROI;
%     ROI_hist_equalized=ROI_hist_equalized/length(find(ROI_window));
%     bar(ROI_hist_equalized)


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Low-Pass Filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GaussianLowpassFilteredmInverseTransform(~ROI_window)=0;
% [Lowpass_Filter_ROI_hist,x]=imhist(GaussianLowpassFilteredmInverseTransform,256);
% Lowpass_Filter_ROI_hist(1)=Lowpass_Filter_ROI_hist(1)-zero_outside_ROI;
% Lowpass_Filter_ROI_hist=Lowpass_Filter_ROI_hist/length(find(ROI_window));
% figure;bar(Lowpass_Filter_ROI_hist)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BW_threshold=graythresh(Image_removingBakcground)

% Below using localized Otsu's method to calculate BW threshold value (v11)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
% The setting of seD is sensitive for the results

%%% Newly built in 'Analysis_fringe_v01.m'
Flag_satisfactory_processing='N'


while ((Flag_satisfactory_processing=='N')|(Flag_satisfactory_processing=='n'))     
        
        Flag_contrast_option = input('Doing Equalization, Manual Contrasting, or Non-contrast-improve? E:Equalization, MC:Manual Contrast, N:non-contrast\n','s');
            if (Flag_contrast_option == 'E')|(Flag_contrast_option == 'e')|(Flag_contrast_option == 'MC')|(Flag_contrast_option == 'mc')
                  m_equalized=m;
                    if (Flag_contrast_option == 'E')|(Flag_contrast_option == 'e')
                    T_hist=round(256*cumsum(ROI_hist));
                    else  
                    PDF_hist=manualhist;
                    T_hist_temp=round(256*cumsum(PDF_hist));
                    close all;
                    T_hist=zeros(1,256+1);
                        for indx=0:256
                            idx=find((T_hist_temp-indx)>=0,1,'first');
                            T_hist(indx+1)=idx;
                        end    
                    end 

                [Tr_hist,m_hist,n_hist]=unique(T_hist);

                m_hist=[-1,m_hist(:)'-1];

                for indx=1:length(Tr_hist) % take advantage of the fact that T(i+1)>=T(i) to speed up the look-up operation
                    idx=m>=(m_hist(indx)+1) & m<=m_hist(indx+1); 
                    m_equalized(idx)=Tr_hist(indx); 
                end

                m_equalized(~ROI_window)=0;
            else    
                   m_equalized=m;
            end
        
        using_filter_index=input('Using low pass filter or not? Y or y:yes, N or n:no\n','s')
        if ((using_filter_index =='Y')|(using_filter_index =='y'))
            filter_size=str2num(input('Input the new value of filter size\n','s'));
            filter_sigma=str2num(input('Input the new value of filter sigma\n','s'));
            GaussianLowpassFilter = fspecial('gaussian', filter_size, filter_sigma);
            m_Spectrum=fftshift(fft2(double(m_equalized)));
            GaussianLowpassFilterSpectrum = fftshift(fft2(GaussianLowpassFilter,size(m_Spectrum,1),size(m_Spectrum,2)));
            GaussianLowpassFilterSpectrum_Logmagnitude=log10(1+abs(GaussianLowpassFilterSpectrum));
            GaussianLowpassFilterSpectrum_Phase=angle(GaussianLowpassFilterSpectrum);
            GaussianLowpassFilteredmSpectrum = m_Spectrum.*GaussianLowpassFilterSpectrum;
            GaussianLowpassFilteredSpectrum_Logmagnitude=log10(1+abs(GaussianLowpassFilteredmSpectrum));
            GaussianLowpassFilteredSpectrum_Phase=angle(GaussianLowpassFilteredmSpectrum);
            Shifted_GaussianLowpassFilteredmInverseTransform = uint8(abs(ifft2(GaussianLowpassFilteredmSpectrum)));
            RowBuffer = circshift(Shifted_GaussianLowpassFilteredmInverseTransform,[-1.*floor(length(GaussianLowpassFilter)/2) 0]);
            ColBuffer = circshift(RowBuffer,[0 -1.*floor(length(GaussianLowpassFilter)/2)]);
            GaussianLowpassFilteredmInverseTransform = ColBuffer;
        else
            GaussianLowpassFilteredmInverseTransform = m_equalized;
        end
            filter_index=sum(sum((GaussianLowpassFilteredmInverseTransform-m).^2))
            
        
        
% (Top-hat Transformations: T_tophat=f-imopen(f,g)
% Used to correct the effects of non-uniform illumination     
        Tophead_transform_flag=input('Doing Top-head Transform? Y or y:Do Top-Head Transform, N or n:Skip\n','s');
        if ((Tophead_transform_flag =='Y')||(Tophead_transform_flag =='y'))
            disk_size_background=str2num(input('Input the new value of background\n','s'));
            background = imopen(GaussianLowpassFilteredmInverseTransform,strel('disk',disk_size_background));
            Image_removingBakcground = imsubtract(GaussianLowpassFilteredmInverseTransform,background);
        else 
            Image_removingBakcground = GaussianLowpassFilteredmInverseTransform;
        end 
        
        Image_removingBakcground(~ROI_window)=0;
        [Otsu_ROI_hist,x]=imhist(Image_removingBakcground,256);
        Otsu_ROI_hist(1)=Otsu_ROI_hist(1)-zero_outside_ROI;
        Otsu_ROI_hist=Otsu_ROI_hist/length(find(ROI_window));

        omega=cumsum(Otsu_ROI_hist);
        mu = cumsum(Otsu_ROI_hist .* (1:256)');
        mu_t = mu(end);

        sigma_b_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));

        maxval = max(sigma_b_squared);
          isfinite_maxval = isfinite(maxval);
          if isfinite_maxval
            idx = mean(find(sigma_b_squared == maxval));
            % Normalize the threshold to the range [0, 1].
            level = (idx - 1) / (256 - 1);
          else
            level = 0.0;
          end
        BW_threshold=level
        
        BW_threshold=str2num(input('Input the new value of BW_threshold\n','s'));
        BW_image=im2bw(Image_removingBakcground, BW_threshold);
        

%       Closing operating: Dilating first, then eroding
%       Closing tends to smooth an image, but it fuses narrow breaks and 
%       thin gulfs and eliminates small holes
        square_size_close=str2num(input('Input the new value of square_size_close\n','s'));
        se = strel('square',square_size_close);
        BW_refined_close=imclose(BW_image,se);
%       Opening operation: Eroding first, then dilating
%       Opening tends to smooth an image, to break narrow joints, and to 
%       remove thin protrusions
        square_size_open=str2num(input('Input the new value of square_size_open\n','s'));
        se = strel('square',square_size_open);
        BW_refined_open=imopen(BW_refined_close,se);

        BW_refined=BW_refined_open;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % This module substitute the imclearborder function. It clear frignes that
        % connect to the ROI borders
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        se = strel('disk',4);     
        im2 = imerode(ROI_window,se);
        im2 = ROI_window & ~ im2;
        im2 = im2 & BW_refined;
        im2 = imreconstruct(im2, BW_refined, 8);
        if islogical(im2)
            BW_noborder = BW_refined & ~im2;
        else
            BW_noborder = imsubtract(BW_refined,im2);
        end

        BW_sk = bwmorph(BW_noborder, 'thin', inf);

        quadruple_connect_1 = FindEndand34druple(BW_sk, 'quadruple');
        intermediate_image1 = BW_sk - quadruple_connect_1;
        triple_connect_1 = FindEndand34druple(intermediate_image1, 'triple');
        intermediate_image2=intermediate_image1 - triple_connect_1; 
        triple_connect_2 = FindEndand34druple(intermediate_image2, 'triple');
        broken_image=intermediate_image2-triple_connect_2; 

        RGB_image_with_nodes(:,:,3)=double(BW_sk)-triple_connect_1-triple_connect_2+quadruple_connect_1; 
        RGB_image_with_nodes(:,:,2)=double(BW_sk)-triple_connect_1+triple_connect_2-quadruple_connect_1; 
        RGB_image_with_nodes(:,:,1)=double(BW_sk)+triple_connect_1-triple_connect_2-quadruple_connect_1;
        RGB_image_with_nodes(RGB_image_with_nodes>=1)=1;
        RGB_image_with_nodes(RGB_image_with_nodes<=0)=0;

        RGB_image_benchmark(:,:,3)=double(256-m)/255-broken_image;
        RGB_image_benchmark(:,:,2)=double(256-m)/255-broken_image;
        RGB_image_benchmark(:,:,1)=double(256-m)/255+broken_image;
        RGB_image_benchmark(RGB_image_benchmark>=1)=1;
        RGB_image_benchmark(RGB_image_benchmark<=0)=0;
        
    figure(1);
    imshow(m);
    colormap(gray);
    axis image;
    figure(2);
    bar(ROI_hist);
    figure(3);
    imshow(m_equalized);
    colormap(gray);
    axis image;

    figure(4)
    [ROI_hist_equalized,x]=imhist(m_equalized,256);
    ROI_hist_equalized(1)=ROI_hist_equalized(1)-zero_outside_ROI;
    ROI_hist_equalized=ROI_hist_equalized/length(find(ROI_window));
    bar(ROI_hist_equalized)

    figure(5)
    imshow(GaussianLowpassFilteredmInverseTransform);
    title('Inverse Gaussuab Lowpass Filtered Image Spatial Image');
    colormap(gray);
    axis image;
    figure(6)
    imshow(Image_removingBakcground);
    title('After removing background');
    colormap(gray);
    axis image;
    figure(7)
    imshow(BW_image);
    title('Binarized');
    colormap(gray);
    axis image;
    figure(8)
    imshow(BW_refined_close);
    title('Refined image - closing');
    colormap(gray);
    axis image;
    figure(9)
    imshow(BW_refined_open+ROI_edge);
    title('Refined image - opening');
    colormap(gray);
    axis image;
    figure(10)
    imshow(BW_noborder+ROI_edge);
    title('Refined image - no contacting ROI border');
    colormap(gray);
    axis image;
    figure(11)
    imshow(BW_sk);
    title('Skeletonized No-border Refined Binarized Image');
    colormap(gray);
    axis image;

    figure(12)
    imshow(RGB_image_with_nodes);
    title('Image with marked nodes');
    axis image;

    figure(13)
    imshow(broken_image);
    title('Breaking Triple and Quadruple cross point Image');
    colormap(gray);
    axis image;
    
    figure(14)
    imshow(RGB_image_benchmark);
    title('Benchmark image to determine satisfication');
    axis image;
    % If not satisfied, start over from the beginning of this while loop
    Flag_satisfactory_processing = input('Is this image processing satisfied? Y: satisfied, N: unsatisfied\n','s');

    
end
close all;

%%


% Start to analyze the image, fringe length and tortuosity 

BW_Analysis=bwlabel(broken_image);
    
STATS=regionprops(BW_Analysis, 'all');

number_of_stats=size(STATS,1)


raw_fringe_length=[];
for indx=1:number_of_stats
    obtain_length_indx=indx
    raw_fringe_length=[raw_fringe_length STATS(indx).Perimeter];
end
% Convert from pixel to nm
raw_fringe_length=raw_fringe_length/2*pixel_to_nm; % divided by 2 because length = perimeter/2 s

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove those impossible fringes and its Statistics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fringe_length_thresh=0.5 %nm

broken_image_updated=broken_image; 
for indx=find(raw_fringe_length<fringe_length_thresh)
     check_length_indx=indx
     broken_image_updated=broken_image_updated-(BW_Analysis==indx);   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%For figure 17
ROI_image=255-m;
%dilated_broken_image_updated=broken_image_updated;
se = strel('diamond',1);
dilated_broken_image_updated=imdilate(broken_image_updated,se);
RGB_image(:,:,3)=double(ROI_image)/255-dilated_broken_image_updated;
RGB_image(:,:,2)=double(ROI_image)/255-dilated_broken_image_updated;
RGB_image(:,:,1)=double(ROI_image)/255+dilated_broken_image_updated;
RGB_image(RGB_image>=1)=1;
RGB_image(RGB_image<=0)=0;

Save_processing_result_flag=input('Save the processing result? Y or y: save, N or n: not save\n','s');
if (Save_processing_result_flag=='Y')||(Save_processing_result_flag=='y')
    processing_date_time=datestr(now);
    save(save_mat_name);
end

%%
figure(1);
imagesc(m_user_selected_ROI);
title('Original Image');
%colormap(gray);
axis image;


figure(2);
imagesc(m);
title('Scale Invert Image');
colormap(gray);
axis image;


figure(3)
imagesc(m_equalized);
title('Image of Contrast Enhancement');
colormap(gray);
axis image;

figure(4);
imagesc(abs(GaussianLowpassFilteredmInverseTransform));
title('Inverse Gaussuab Lowpass Filtered Image Spatial Image');
colormap(gray);
axis image;

figure(5)
imagesc(Image_removingBakcground);
title('Removing Background Image');
colormap(gray);
axis image;

figure(6)
imagesc(BW_image);
title('Binarized Image');
colormap(gray);
axis image;

figure(7)
imagesc(or(BW_refined,ROI_edge));
title('Binarized Image');
colormap(gray);
axis image;

figure(8)
imagesc(or(BW_noborder,ROI_edge));
title('No-border Refined Binarized Image');
colormap(gray);
axis image;

figure(9)
imagesc(BW_sk);
title('Skeletonized No-border Refined Binarized Image');
colormap(gray);
axis image;

figure(10)
imagesc(RGB_image_with_nodes);
title('Image with marked nodes');
axis image;

figure(11)
imagesc(broken_image);
title('Breaking Triple and Quadruple cross point Image');
colormap(gray);
axis image;

figure (12)
imagesc(broken_image_updated);
title('Updated point Image after removing short length');
colormap(gray);
axis image;

figure(13)
subplot(211)
imagesc(ROI_image);
title('SOI Image');
colormap(gray);
axis image;
[Hscale,Htext]=plot_scale([800 150],pixel_to_nm,6,'r','nm','h');

subplot(212)
imagesc(RGB_image);
title('RGB Image');
axis image;
[Hscale,Htext]=plot_scale([800 150],pixel_to_nm,6,'r','nm','h');

end
